import { useState, useEffect, useCallback, useMemo } from 'react';
import { HorizontalPageScroll } from '@/components/ui/horizontal-page-scroll';
import testData from './requiredFiles/test_data.json';
import { useTaskTranslations } from '@/lib/useTaskTranslations';

const NumberCard = ({ number, prediction, modulo, onSelect }) => {
  
  const classes = Array.from({ length: modulo }, (_, i) => i);
  
  return (
    <div className="border-2 border-muted rounded-lg p-3 bg-card">
      <div className="text-center mb-3">
        <div className="text-3xl font-bold font-mono">{number}</div>
      </div>
      <div className="mt-2">
        <select
          value={prediction !== null && prediction !== undefined ? prediction : ''}
          onChange={(e) => onSelect(e.target.value === '' ? null : parseInt(e.target.value))}
          className="w-full px-3 py-2 rounded border border-muted bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
        >
          <option value=""></option>
          {classes.map((cls) => (
            <option key={cls} value={cls}>
              {cls}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
};

function App({ levelId, value, onChange, disabled }) {
  const tt = useTaskTranslations();
  
  const [currentPage, setCurrentPage] = useState(0);

  const numbers = testData[levelId]?.numbers || [];
  const modulo = testData[levelId]?.modulo || 2;
  
  const predictions = useMemo(() => {
    if (!value || !Array.isArray(value)) {
      return Array(numbers.length).fill(null);
    }
    return value;
  }, [value, numbers.length]);

  useEffect(() => {
    if (!value) {
      onChange(Array(numbers.length).fill(null));
    }
  }, [levelId, numbers.length]);

  const selectPrediction = useCallback((index, cls) => {
    const newPredictions = [...predictions];
    newPredictions[index] = cls;
    onChange(newPredictions);
  }, [predictions, onChange]);

  const numbersPerPage = 10;
  const totalPages = Math.ceil(numbers.length / numbersPerPage);

  const renderPage = useCallback((pageIndex) => {
    const startIdx = pageIndex * numbersPerPage;
    const endIdx = Math.min(startIdx + numbersPerPage, numbers.length);
    const pageNumbers = numbers.slice(startIdx, endIdx);
    
    return (
      <div className="grid grid-cols-5 gap-3">
        {pageNumbers.map((number, idx) => {
          const absoluteIndex = startIdx + idx;
          return (
            <NumberCard
              key={absoluteIndex}
              number={number}
              prediction={predictions[absoluteIndex]}
              modulo={modulo}
              onSelect={(cls) => !disabled && selectPrediction(absoluteIndex, cls)}
            />
          );
        })}
      </div>
    );
  }, [numbers, numbersPerPage, predictions, modulo, selectPrediction, disabled]);

  const completedCount = predictions.filter(p => p !== null && p !== undefined).length;

  return (
    <div className="space-y-4">
      <h4>{tt('hint')} {modulo}</h4>
      <div>
        {tt('yourPredictions')}: 
        <span className="font-medium"> {completedCount}</span>
        <span className="text-muted-foreground"> / {numbers.length}</span>
      </div>
      {/* Paginated Number Grid */}
      <HorizontalPageScroll
        totalPages={totalPages}
        renderPage={renderPage}
        currentPage={currentPage}
        onPageChange={setCurrentPage}
        prerenderBuffer={1}
        pageLabel={tt('page')}
        totalInfo={tt('numbersTotal', { count: numbers.length })}
      />

      
    </div>
  );
}

export default App;
